import model.*;import service.*;public class OrderManagementSystem {
    public static void main(String[] a)throws Exception{
        OrderService s=new OrderService();
        OrderRequest r=new OrderRequest("User",1,2,100,"Addr",false,"",new OrderDate(1,1,2026));
        s.process(r);
    }
}