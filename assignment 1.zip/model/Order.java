package model;
public class Order {
    private final OrderRequest request;
    private final double total;
    public Order(OrderRequest r,double t){request=r;total=t;}
    public OrderRequest getRequest(){return request;}
    public double getTotal(){return total;}
}