package model;
public class OrderRequest {
    private final String userName,address,notes;
    private final int productId;
    private int quantity;
    private final double price;
    private final boolean urgent;
    private final OrderDate date;
    public OrderRequest(String u,int p,int q,double pr,String a,boolean ur,String n,OrderDate d){
        userName=u;productId=p;quantity=q;price=pr;address=a;urgent=ur;notes=n;date=d;
    }
    public void adjustQuantityIfUrgent(){if(urgent)quantity++;}
    public boolean isValid(){return quantity>0&&price>0;}
    public String getUserName(){return userName;}
    public int getProductId(){return productId;}
    public int getQuantity(){return quantity;}
    public double getPrice(){return price;}
    public OrderDate getOrderDate(){return date;}
}