package model;
public class OrderDate {
    private final int day,month,year;
    public OrderDate(int d,int m,int y){day=d;month=m;year=y;}
    public String getFormattedDate(){return day+"/"+month+"/"+year;}
}