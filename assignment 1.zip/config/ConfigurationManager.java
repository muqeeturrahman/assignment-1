package config;
import enums.*;
public class ConfigurationManager {
    private UserRole role=UserRole.GUEST;
    private PaymentType payment=PaymentType.CASH;
    public UserRole getUserRole(){return role;}
    public PaymentType getPaymentType(){return payment;}
}