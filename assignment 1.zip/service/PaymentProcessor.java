package service;
import enums.PaymentType;
public class PaymentProcessor {
    public static void process(PaymentType p){System.out.println(p.getDisplayName());}
}