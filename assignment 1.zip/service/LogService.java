package service;
import java.util.*;import java.io.*;
public class LogService {
    private final List<String> logs=new ArrayList<>();
    public void add(String m){logs.add(m);}
    public void flush()throws IOException{
        try(FileWriter f=new FileWriter("logs.txt")){
            for(String l:logs)f.write(l+"\n");
        }
    }
}