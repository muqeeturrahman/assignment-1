package service;
import enums.UserRole;
public class DiscountCalculator {
    public static double apply(UserRole u,double b){return b-u.getDiscountAmount();}
}