package service;
public class NotificationService {
    public static void notify(String u,String m){System.out.println(u+":"+m);}
}