package service;
public class ShippingCalculator {
    public static int cost(int d){
        if(d<10)return 50;
        if(d<50)return 100;
        if(d<100)return 150;
        return 200;
    }
}