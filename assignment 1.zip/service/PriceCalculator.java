package service;
import enums.UserRole;
import model.OrderRequest;
public class PriceCalculator {
    private static final double A=10,B=20;
    public static double calculate(OrderRequest r,UserRole u){
        return r.getQuantity()*r.getPrice()+A+B+u.getDiscountAmount();
    }
}