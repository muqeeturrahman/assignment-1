package service;
import model.*;
public class ReportGenerator {
    public static void report(Order o){
        System.out.println(o.getRequest().getUserName()+":"+o.getTotal());
    }
}