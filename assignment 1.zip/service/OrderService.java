package service;
import model.*;import repository.*;import config.*;import java.io.*;
public class OrderService {
    private final OrderRepository repo=new OrderRepository();
    private final ConfigurationManager cfg=new ConfigurationManager();
    public void process(OrderRequest r)throws IOException{
        r.adjustQuantityIfUrgent();
        if(!r.isValid())return;
        double t=PriceCalculator.calculate(r,cfg.getUserRole());
        Order o=new Order(r,t);
        repo.save(o);
        PaymentProcessor.process(cfg.getPaymentType());
        ReportGenerator.report(o);
    }
}