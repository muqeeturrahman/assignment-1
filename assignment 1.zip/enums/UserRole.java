package enums;
public enum UserRole {
    PREMIUM(10.0), REGULAR(2.0), GUEST(1.0);
    private final double discountAmount;
    UserRole(double d){this.discountAmount=d;}
    public double getDiscountAmount(){return discountAmount;}
}