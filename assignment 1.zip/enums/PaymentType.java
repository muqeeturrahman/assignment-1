package enums;
public enum PaymentType {
    CASH("Cash"), CARD("Card"), BANK("Bank"), OTHER("Other");
    private final String displayName;
    PaymentType(String d){this.displayName=d;}
    public String getDisplayName(){return displayName;}
}