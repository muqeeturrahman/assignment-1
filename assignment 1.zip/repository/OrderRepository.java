package repository;
import model.Order;
import java.io.*;
public class OrderRepository {
    public void save(Order o)throws IOException{
        try(FileWriter f=new FileWriter("orders.txt",true)){
            f.write(o.getRequest().getUserName()+","+o.getTotal()+"\n");
        }
    }
}